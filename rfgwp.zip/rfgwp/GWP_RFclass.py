# coding: utf-8
import sys
if len(sys.argv) < 4:
    print("")
    print(sys.argv[0],"is designed to predict the value of GWP( TH=100 year ) for insulation gas.")
    print("Class_1: GWP <= 1000")
    print("Class_2: GWP > 1000")
    print("usage:  ")
    print("")
    print(sys.argv[0], "<SMILES code>", "<HOMO Energy>","<LUMO Energy>","<output csv file>")
    print("")
    print("For example:")
    print("")
    print(sys.argv[0],"'FC(F)(F)/C=C/C(F)(F)F'", "-0.34983","-0.06764", "foo_result.csv")
    print("")
    print("Any question, Please feel free to contact me.")
    print("")
    print("Mr. Gaokeng Xiao  Tel:18665593435  Email: gkxiao@molcalx.com")
    print("")
    sys.exit()



#input: SMILES, E_HOMO and E_LUMO calculated at APFD/6-311+g(2d,p) level

#IPCC057
smi = sys.argv[1]
E_HOMO = float(sys.argv[2]) 
E_LUMO = float(sys.argv[3])
output = sys.argv[4]
gwpmodel = '/public/gkxiao/work/gwp/20190414/gwpclass_apfd_rf.model'
gwpmodel_scaler = '/public/gkxiao/work/gwp/20190414/gwpclass_apfd_rf_scaler.npy'
# In[3]:


#create a prediction set and calculate descriptor
from rdkit import Chem
import pandas as pd
predset=pd.DataFrame({'SMILES':[smi]})
predset['Mol'] = predset['SMILES'].apply(Chem.MolFromSmiles)
predset['E_HOMO'] = E_HOMO
predset['E_LUMO'] = E_LUMO


# In[4]:


#RDkit for fingerprinting and cheminformatics
def elemCount(smiles):
    """
    calculate atom and bond count. Return：
    nH： Hydrogen count
    nCD：count of C=X bond 
    nCT：count of C#X bond
    nCDT： both nC2 and nC3
    """
    from rdkit import Chem, DataStructs
    from rdkit.Chem import AllChem
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        pass
    m = Chem.AddHs(m)
    nH = len(m.GetSubstructMatches(Chem.MolFromSmarts('[C][H]')))
    nCd = len(m.GetSubstructMatches(Chem.MolFromSmarts('C=[O,C,N,S]')))
    nCt = len(m.GetSubstructMatches(Chem.MolFromSmarts('C#[O,C,N]')))
    nCdt = nCd + nCt
    return nH,nCdt


# In[5]:


H = []
Cdt = []
for mol in predset['SMILES']:
    nH,nCdt = elemCount(mol)
    H.append(nH)
    Cdt.append(nCdt)
predset['nH'] = H
predset['nCdt'] = Cdt


# In[6]:


# Import libraries and modules
import numpy as np
import pandas as pd
from sklearn import preprocessing
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.externals import joblib

# load model
GWPclass = joblib.load(gwpmodel)

#load preprocession parameters
scaler_data_ = np.load(gwpmodel_scaler)
Xmean_, Xscale_ = scaler_data_[0], scaler_data_[1]


# In[7]:


data_cols = ['E_HOMO', 'E_LUMO','nH','nCdt']
Xscaled = predset[data_cols]
Xscaled = (Xscaled - Xmean_)/Xscale_


# In[10]:


#predict boiling point
predset['Class_Pred'] = GWPclass.predict(Xscaled)[0]


# In[13]:


cols=['SMILES','E_HOMO','E_LUMO','nH','nCdt','Class_Pred']

result = predset[cols]
result.to_csv(output)
